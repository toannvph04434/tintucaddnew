package com.lypo.joker.docjson;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    final String API = "http://webtintuccc.esy.es/";
    ListView listView;
    ArrayList<tintuc> arrTT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = (ListView) findViewById(R.id.listView);
        arrTT = new ArrayList<tintuc>();
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                new doGetTT().execute(API);
            }
        });
    }
        //Lay Json ve
    class doGetTT extends AsyncTask<String, Integer, String> {
        //download du lieu xong roi xuong ham postex
        @Override
        protected String doInBackground(String... params) {
//load du lieu noi dung cua trang web tra ve noi dung
            return docNoiDung_Tu_URL(params[0]);
        }
// khi tra ve thi ham nay doc va truyen ket qua do vao
        @Override
        protected void onPostExecute(String s) {
            try {
                //Tra ve mang Json
                JSONArray jsonArray = new JSONArray(s);
                //Doc tung doi tuong co trong mang Json
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject objecttt = jsonArray.getJSONObject(i);
                    //add vào doi tuong tintuc
                    arrTT.add(new tintuc(
                            objecttt.getInt("id"),
                            objecttt.getString("loaitin"),
                            objecttt.getString("tieude"),
                            objecttt.getString("anh"),
                            objecttt.getString("noidung"),
                            objecttt.getString("ngay"),
                            objecttt.getString("gio")

                    ));
                }
                //Custom ra list view
                Ctom2 listAdapter = new Ctom2(getApplicationContext(), R.layout.activity_custom_list, arrTT);
                listView.setAdapter(listAdapter);
                Toast.makeText(getApplicationContext(), "" + arrTT.size(), Toast.LENGTH_LONG).show();
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        //Toast.makeText(getApplicationContext(),""+arrTT.get(position).getIdtt(),Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(MainActivity.this, ChiTiet.class);
                        intent.putExtra("name", String.valueOf(arrTT.get(position).getIdtt()));
                        startActivity(intent);
                    }
                });
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
    // truyen vao mot dia chi trang web va gui noi dung do ra
    private static String docNoiDung_Tu_URL(String theUrl) {
        StringBuilder content = new StringBuilder();

        try {
            // create a url object
            URL url = new URL(theUrl);

            // create a urlconnection object
            URLConnection urlConnection = url.openConnection();

            // wrap the urlconnection in a bufferedreader
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));

            String line;

            // read from the urlconnection via the bufferedreader
            while ((line = bufferedReader.readLine()) != null) {
                content.append(line + "\n");
            }
            bufferedReader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return content.toString();
    }

}
